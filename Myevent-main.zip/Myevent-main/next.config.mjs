/** @type {import('next').NextConfig} */
const nextConfig = {};

export default nextConfig;


// const path = require('path');

// module.exports = {
//   // ... rest of Webpack configuration
//   resolve: {
//     alias: {
//       "@/types": path.resolve(__dirname, "src/types"),
//       // ... other aliases
//     }
//   }
// };
